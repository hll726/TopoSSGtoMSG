Readme for TopoSSGtoMSG Package

Overview
The TopoSSGtoMSG package enables the computation of the topology of arbitrary collinear magnets under spin space groups and magnetic space groups, covering the vanishing-SOC regime, the negligible-SOC limit, and the realistic-SOC case for various magnetic-moment orientations. This unified framework allows one to systematically elucidate how SOC reshapes the topological properties of materials.
